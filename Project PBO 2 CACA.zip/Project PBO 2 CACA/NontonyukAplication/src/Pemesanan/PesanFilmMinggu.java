
package Pemesanan;

import app.db.Mahasiswa;
import app.db.MahasiswaManager;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class PesanFilmMinggu extends javax.swing.JInternalFrame {
    List<Mahasiswa> mahasiswa = new ArrayList<>();
     int currentRow = 0;

    public PesanFilmMinggu() {
        String lookAndFeel = javax.swing.UIManager.getSystemLookAndFeelClassName();
            try {
                javax.swing.UIManager.setLookAndFeel(lookAndFeel);
            } catch (Exception e) {
            }       
        
        initComponents();
        loadData();
        bindData();
        
    }

        private void loadData() {
        MahasiswaManager mhsmgr = new MahasiswaManager();
        mahasiswa = mhsmgr.getMahasiswa();
        mhsmgr.closeConnection();
    }
     private void bindData() {
        if (mahasiswa.size()>0) {
            Mahasiswa m = mahasiswa.get(currentRow);
            Idtxt.setText(m.getidpelanggan());
            Namatxt.setText(m.getnama());
            Judultxt.setText(m.getjudulfilm());
            Hargatxt.setText(m.getharga());
            Pembayarantxt.setText(m.getpembayaran());
        } else {
            currentRow = 0;
            Idtxt.setText("");
            Namatxt.setText("");
            Judultxt.setText("");
            Hargatxt.setText("");
            Pembayarantxt.setText("");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Idtxt = new javax.swing.JTextField();
        Namatxt = new javax.swing.JTextField();
        Judultxt = new javax.swing.JTextField();
        Pembayarantxt = new javax.swing.JTextField();
        JudulCbx = new javax.swing.JComboBox<>();
        Hargatxt = new javax.swing.JTextField();
        Bayarbtn = new javax.swing.JButton();

        setClosable(true);
        setTitle("Minggu");

        jLabel2.setText("Nama");

        jLabel3.setText("Judul Film");

        jLabel5.setText("Pembayaran");

        jLabel1.setText("ID Pelanggan");

        jLabel4.setText("Harga");

        Namatxt.setText("ISI NAMA");

        JudulCbx.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "F001", "F002", "F003", "F004", "F005", " " }));
        JudulCbx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JudulCbxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Pembayarantxt, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addComponent(Hargatxt)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Namatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(JudulCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Judultxt)))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Namatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JudulCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(Judultxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Hargatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Pembayarantxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44))
        );

        Bayarbtn.setText("Bayar");
        Bayarbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BayarbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Bayarbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Bayarbtn)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JudulCbxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JudulCbxActionPerformed
        switch(JudulCbx.getSelectedIndex()) {
            case 0 -> {
                Judultxt.setText("0");
                Hargatxt.setText("0");
            }
            case 1 -> {
                Judultxt.setText("ANCIKA: DIA YANG BERSAMAKU 1995");
                Hargatxt.setText("50000");
            }
            case 2 -> {
                Judultxt.setText("13 BOM DI JAKARTA");
                Hargatxt.setText("50000");
            }
            case 3 -> {
                Judultxt.setText("SEHIDUP SEMATI");
                Hargatxt.setText("50000");
            }
            case 4 -> {
                Judultxt.setText("SIKSA NERAKA");
                Hargatxt.setText("50000");
            }
            case 5 -> {
                Judultxt.setText("MONSTER");
                Hargatxt.setText("50000");
            }
        }
    }//GEN-LAST:event_JudulCbxActionPerformed

    private void BayarbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BayarbtnActionPerformed
        if(Hargatxt.getText().isEmpty() && Pembayarantxt.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Pilih Film Yang Mau Anda Tonton");
        }else if(Double.parseDouble(Pembayarantxt.getText()) < (Double.parseDouble(Hargatxt.getText()))){   
            JOptionPane.showMessageDialog(null, "Uang Pembayaran Kurang");
        }else{
           if (!Idtxt.getText().equals("") && !Pembayarantxt.getText().equals("")){
           MahasiswaManager mhsmgr = new MahasiswaManager();
           Mahasiswa m = new Mahasiswa();
           m.setidpelanggan(Idtxt.getText());
           m.setnama(Namatxt.getText());         
           m.setjudulfilm(Judultxt.getText());
           m.setharga(Hargatxt.getText());
           m.setpembayaran(Pembayarantxt.getText());
           if (mhsmgr.Insert(m)>0) {
               loadData();
               currentRow = mahasiswa.size()-1;
               bindData();
               JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan","Informasi", JOptionPane.INFORMATION_MESSAGE);
           } else {
              JOptionPane.showMessageDialog(this, "Data Gagal Disimpan","Informasi", JOptionPane.INFORMATION_MESSAGE);
           }
           Idtxt.setEditable(false);
           Namatxt.setEditable(false);          
           Judultxt.setEditable(false);           
           JudulCbx.setEditable(false);
           Hargatxt.setEditable(false);
           Pembayarantxt.setEditable(false);
           mhsmgr.closeConnection();
          } else {
           JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan","Informasi", JOptionPane.INFORMATION_MESSAGE);
          }            
            Penyelesaian penyelesaian = new Penyelesaian(Judultxt.getText(), Hargatxt.getText(), Pembayarantxt.getText());
            penyelesaian.setVisible(true);
            this.getDesktopPane().add(penyelesaian);
            this.dispose();
        }
    }//GEN-LAST:event_BayarbtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Bayarbtn;
    private javax.swing.JTextField Hargatxt;
    private javax.swing.JTextField Idtxt;
    private javax.swing.JComboBox<String> JudulCbx;
    private javax.swing.JTextField Judultxt;
    private javax.swing.JTextField Namatxt;
    private javax.swing.JTextField Pembayarantxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
