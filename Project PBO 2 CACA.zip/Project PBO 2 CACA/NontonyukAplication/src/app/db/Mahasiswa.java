package app.db;

public class Mahasiswa {

    private String Id_Pelanggan;
    private String Nama;
    private String Judul_Film;
    private String Harga;
    private String Pembayaran;

    public Mahasiswa() {

    }

    public String getpembayaran() {
        return Pembayaran;
    }

    public void setpembayaran(String pembayaran) {
        this.Pembayaran = pembayaran;
    }

    public String getharga() {
        return Harga;
    }

    public void setharga(String harga) {
        this.Harga = harga;
    }

    public String getjudulfilm() {
        return Judul_Film;
    }

    public void setjudulfilm(String judul_film) {
        this.Judul_Film = judul_film;
    }

    public String getnama() {
        return Nama;
    }

    public void setnama(String nama) {
        this.Nama = nama;
    }
    
    public String getidpelanggan() {
        return Id_Pelanggan;
    }

    public void setidpelanggan(String id_pelanggan) {
        this.Id_Pelanggan = id_pelanggan;
    }

}

